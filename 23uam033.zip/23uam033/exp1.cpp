#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
	int num1,num2;
	int add,sub, mul;
	float div;
	
	cout<<"enter 2 numbers :";
	cin>>num1>>num2;
	
	add=num1+num2;
	sub=num1-num2;
	mul=num1*num2;
	div=num1/num2;
	
	cout<<"addition"<<" "<<setw(5)<<add;
	cout<<"\nsubstraction"<<" "<<setw(5)<<sub;
	cout<<"\nmultiplication"<<" "<<setw(5)<<mul;
	cout<<"\ndivision"<<" "<<setw(5)<<div;
}





	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
