#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
	 int num1,num2,num3;
	 int larger_no;
	
	cout<<"enter 3 numbers :";
	cin>>num1>>num2>>num3;
	
	if(num>=num2&&num1)
		larger_no=num1;
	else if(num2>=num1 && num2>=num3)
        larger_no=num1;
    else
        larger_no=3;
        
        
    cout<<"largest no:"<<larger_no;
    
    
}
